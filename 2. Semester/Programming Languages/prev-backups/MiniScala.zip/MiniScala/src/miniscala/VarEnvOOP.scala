package miniscala

type Var = String

object VarEnvOOP {
  sealed abstract class VarEnv {
    def makeEmpty(): VarEnv = NilVarEnv
    def extend(e: VarEnv, x:Var, v: Int): VarEnv = ConsVarEnv(x, v, e)
    def lookup(x: Var): Int
  }

  case object NilVarEnv extends VarEnv {
    def lookup(x: Var): Int = throw new RuntimeException("not found")
  }

  case class ConsVarEnv(x: Var, v: Int, next: VarEnv) extends VarEnv {
    def lookup(x: Var): Int = {
      if (this.x == x) this.v
      else next.lookup(x)
    }
  }

  def main(args: Array[String]): Unit = {
    var varEnvTest: VarEnv = NilVarEnv
    varEnvTest = varEnvTest.extend(varEnvTest, "x", 5)
    varEnvTest = varEnvTest.extend(varEnvTest, "y", 7)
    assert(varEnvTest.lookup("x")==5)
    assert(varEnvTest.lookup("y")==7)
    varEnvTest = varEnvTest.makeEmpty()
    assert(varEnvTest == NilVarEnv)
  }
}

