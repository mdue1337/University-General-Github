package miniscala

import miniscala.Ast.*
import miniscala.Unparser.unparse

/**
  * Type checker for MiniScala.
  */
object TypeChecker {
  type VarTypeEnv = Map[Var, Type]

  def typeCheck(e: Exp, vtenv: VarTypeEnv): Type = e match {
    case IntLit(_) => IntType()
    case BoolLit(_) => BoolType()
    case FloatLit(_) => FloatType()
    case StringLit(_) => StringType()
    case VarExp(x) => vtenv.getOrElse(x, throw TypeError(s"Unknown identifier '$x'", e))
    case BinOpExp(leftexp, op, rightexp) =>
      val lefttype = typeCheck(leftexp, vtenv)
      val righttype = typeCheck(rightexp, vtenv)
      op match {
        case PlusBinOp() =>
          (lefttype, righttype) match {
            case (IntType(), IntType()) => IntType()
            case (FloatType(), FloatType()) => FloatType()
            case (IntType(), FloatType()) => FloatType()
            case (FloatType(), IntType()) => FloatType()
            case (StringType(), StringType()) => StringType()
            case (StringType(), IntType()) => StringType()
            case (StringType(), FloatType()) => StringType()
            case (IntType(), StringType()) => StringType()
            case (FloatType(), StringType()) => StringType()
            case _ => throw TypeError(s"Type mismatch at '+', unexpected types ${unparse(lefttype)} and ${unparse(righttype)}", op)
          }

        // Shouldnt you be able to multiply? "AU"*3 = "AUAUAU"?
        case MinusBinOp() | MultBinOp() | ModuloBinOp() | DivBinOp() | MaxBinOp() =>
          (lefttype, righttype) match {
            case (IntType(), IntType()) => IntType()
            case (FloatType(), FloatType()) => FloatType()
            case (IntType(), FloatType()) => FloatType()
            case (FloatType(), IntType()) => FloatType()
            case _ => throw TypeError(s"Type mismatch at '*' or '/' or 'max' or 'mod', unexpected types ${unparse(lefttype)} and ${unparse(righttype)}", op)
          }

        case EqualBinOp() => (lefttype, righttype) match {
          case (IntType(), IntType()) => BoolType()
          case (FloatType(), FloatType()) => BoolType()
          case (IntType(), FloatType()) => BoolType()
          case (FloatType(), IntType()) => BoolType()
          case (StringType(), StringType()) => BoolType()
          case (BoolType(), BoolType()) => BoolType()
          case (TupleType(v1),TupleType(v2))=>
            if (v1.length != v2.length)
              throw TypeError(s"Case mismatch: (EqualBinOp) Tuples must be same size ${lefttype} and ${righttype}", op)
            else BoolType()
          case _ => throw TypeError(s"Case mismatch: unexpected types ${unparse(lefttype)} and ${unparse(righttype)}", op)
        }

        case LessThanBinOp() | LessThanOrEqualBinOp() => (lefttype, righttype) match {
          case (IntType(), IntType()) => BoolType()
          case (FloatType(), FloatType()) => BoolType()
          case (IntType(), FloatType()) => BoolType()
          case (FloatType(), IntType()) => BoolType()
          case _ => throw TypeError(s"Case mismatch: unexpected types ${unparse(lefttype)} and ${unparse(righttype)}", op)
        }

        case AndBinOp() | OrBinOp() => (lefttype, righttype) match {
          case (BoolType(), BoolType()) => BoolType()
          case _ => throw TypeError(s"'And' or 'Or' must be booleans, unexpected types ${unparse(lefttype)} and ${unparse(righttype)}", op)
        }
      }

    case UnOpExp(op, exp) =>
      val exptype = typeCheck(exp, vtenv)
      op match {
      case NegUnOp() => exptype match {
        case IntType() => IntType()
        case FloatType() => FloatType()
        case _ => throw TypeError(s"Negation must be int or float, unexpected types ${unparse(exp)}", op)
      }
      case NotUnOp() => exptype match {
        case BoolType() => BoolType()
        case _ => throw TypeError(s"Not' must be boolean, unexpected types ${unparse(exp)}", op)
      }
    }

    case IfThenElseExp(condexp, thenexp, elseexp) =>
      val cExp = typeCheck(condexp, vtenv)
      val tExp = typeCheck(thenexp, vtenv)
      val eExp = typeCheck(elseexp, vtenv)

      cExp match {
        case BoolType() => (tExp, eExp) match {
          case (IntType(), IntType()) => IntType()
          case (FloatType(), FloatType()) => FloatType()
          case (StringType(), StringType()) => StringType()
          case (BoolType(), BoolType()) => BoolType()
          case (TupleType(aList), TupleType(bList)) =>
            for((a,b) <- aList.zip(bList)){
              if(a != b) throw TypeError(s"Case mismatch: Tuples do not match. ${aList}, ${bList}", cExp)
            }
            TupleType(aList)
            
          case _ => throw TypeError(s"Case mismatch: unexpected types ${unparse(tExp)}, ${unparse(eExp)}", thenexp)
        }
        case _ => throw TypeError(s"Condition expression must be boolean, found ${unparse(cExp)}", condexp)
      }

    case BlockExp(vals, exp) =>
      var vtenv1 = vtenv
      for (d <- vals) {
        val t = typeCheck(d.exp, vtenv1)
        checkTypesEqual(t, d.opttype, d)
        vtenv1 = vtenv1 + (d.x -> d.opttype.getOrElse(t))
      }
      typeCheck(exp, vtenv1)

    case TupleExp(exps) => TupleType(exps.map(e => typeCheck(e, vtenv)))

    case MatchExp(exp, cases) =>
      val exptype = typeCheck(exp, vtenv)
      exptype match {
        case TupleType(ts) =>
          var res: Option[Type] = None
          for (c <- cases) {
            if (ts.length == c.pattern.length) {
              var extendedEnv = vtenv
              for ((x, t) <- c.pattern.zip(ts)) {
                extendedEnv += (x -> t)
              }
              val caseType = typeCheck(c.exp, extendedEnv)

              res match {
                case None => res = Option(caseType)
                case Some(prevType) => checkTypesEqual(prevType, Option(caseType), c)
              }
            }
          }
          res match {
            case Some(t) => t
            case None => throw TypeError(s"No case matches type ${unparse(exptype)}", e)
          }

        case _ => throw TypeError(s"Tuple expected at match, found ${unparse(exptype)}", e)
      }
  }

  /**
    * Checks that the types `t1` and `ot2` are equal (if present), throws type error exception otherwise.
    */
  def checkTypesEqual(t1: Type, ot2: Option[Type], n: AstNode): Unit = ot2 match {
    case Some(t2) => if (t1 != t2) throw TypeError(s"Type mismatch: expected type ${unparse(t2)}, found type ${unparse(t1)}", n)
    case None => // do nothing
  }

  /**
    * Builds an initial type environment, with a type for each free variable in the program.
    */
  def makeInitialVarTypeEnv(program: Exp): VarTypeEnv = {
    var vtenv: VarTypeEnv = Map()
    for (x <- Vars.freeVars(program))
      vtenv = vtenv + (x -> IntType())
    vtenv
  }

  /**
    * Exception thrown in case of MiniScala type errors.
    */
  class TypeError(msg: String, node: AstNode) extends MiniScalaError(s"Type error: $msg", node.pos)
}
