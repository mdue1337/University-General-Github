package miniscala

import miniscala.Ast.*

/**
  * Unparser for MiniScala.
  */
object Unparser {
    /**
     * Unparse function.
     * Used for all kinds of AstNode objects, including Exp objects (see Ast.scala).
     */
    def unparse(n: AstNode): String = n match {
      case (e: Exp) =>
        e match {
          case IntLit(c) => s"$c"

          case BoolLit(c) => s"$c"

          case FloatLit(c) => s"$c"

          case StringLit(c) => s"$c"

          case VarExp(c) => s"$c"

          case BinOpExp(leftexp, op, rightexp) => s"(${unparse(leftexp)} ${unparse(op)} ${unparse(rightexp)})"

          case UnOpExp(op, exp) => s"(${unparse(op)} ${unparse(exp)})"

          case BlockExp(vals, exp) => s"{${vals.map(d => unparse(d)).mkString("; ")}; ${unparse(exp)}}"

          case IfThenElseExp(cond, thenExp, elseExp) =>  s"(if ${unparse(cond)} then ${unparse(thenExp)} else ${unparse(elseExp)})"

          case TupleExp(elements) => s"(${elements.map(unparse).mkString(", ")})"

          case MatchExp(exp, cases) => s"(match ${unparse(exp)} { ${cases.map(c => s"(${c.pattern.mkString(",")}) => ${unparse(c.exp)}").mkString("; ")} })"

        }

      case ValDecl(x, opt, exp) => s"val $x = ${unparse(exp)}"

      case (op: BinOp) =>
        op match {
          case PlusBinOp() => "+"
          case MinusBinOp() => "-"
          case MultBinOp() => "*"
          case DivBinOp() => "/"
          case ModuloBinOp() => "%"
          case MaxBinOp() => "max"

          case EqualBinOp() => "="
          case LessThanBinOp() => "<"
          case LessThanOrEqualBinOp() => "<="
          case AndBinOp() => "&&"
          case OrBinOp() => "||"
        }
      case (uop: UnOp) =>
        uop match {
          case NegUnOp() => "-"
          case NotUnOp() => "!"
        }
    }

    def unparse(ot: Option[Type]): String = ot match {
      case Some(t) => ": " + unparse(t)
      case None => ""
    }

    def unparse(t: Type): String = t match {
      case IntType() => "Int"
      case BoolType() => "Bool"
      case FloatType() => "Float"
      case StringType() => "String"
      case TupleType(ts) => ts.map(unparse).mkString("(", ", ", ")")
  }


}
