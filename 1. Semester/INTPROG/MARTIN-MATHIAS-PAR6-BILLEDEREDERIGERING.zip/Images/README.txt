Afprøv metoden på picture.png. Hvad sker der, hvis I først laver billedet lysere og derefter
mørkere? Vil I så være tilbage til det billede, som I startede med? Svaret skrives i
README.TXT.

1. Opgave
Nej, det vill ikke altid være det samme fordi, gråtonen er i [0; 255], det vil sige at hvis man f.eks. tilføjer 50 til en på 254 så vil den ende med 255, da den hardcapper på højeste tal i intervallet. Det kan dog gælde for nogle værdier.

2. Opgave
Nej det kan man ikke da man skal vælge pixels for et billed og gemmer det i det andet. Hvis du skulle lave mirror i samme billed, kan du kun tage værdierne for halvdelen.

