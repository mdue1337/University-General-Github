public class Main {
     public void main(String[] args){
         GUI.createGameBoard();
     }
}
